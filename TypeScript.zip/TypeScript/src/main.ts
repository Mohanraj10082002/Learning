let username = 'madhav'
let a: number = 12
let b: number = 6
let c: number = 2
console.log(username)
console.log(a / b)
console.log(c * b)
interface Guitarist {
    name: string, 
    active?:  boolean, 
    albums: (string | number)[] 
}

    let  evh: Guitarist = {
    name: 'Eddie', active: false, albums: [1984,5150, 'OU243']
    }

    let  AD: Guitarist = {
    name: 'ADF', albums: [1454,2345, 'OU243']
    }
    const greetGuitarist = (guitarist: Guitarist) => {
        return 'Hello ${guitarist.name}!'
    }

    console.log(greetGuitarist(AD))   